var structas2transition_1_1Config_1_1PredFormat =
[
    [ "type", "structas2transition_1_1Config_1_1PredFormat.html#a54e0bd339c456f08ffa6cc9fb856847d", [
      [ "RAW", "structas2transition_1_1Config_1_1PredFormat.html#a54e0bd339c456f08ffa6cc9fb856847dab95c8ed497c11893947076ea52f17056", null ],
      [ "INNER", "structas2transition_1_1Config_1_1PredFormat.html#a54e0bd339c456f08ffa6cc9fb856847daaf432ec2ac026465bfc26a5a9978b22b", null ],
      [ "EQL", "structas2transition_1_1Config_1_1PredFormat.html#a54e0bd339c456f08ffa6cc9fb856847da697b38eb39012b7601400d2531d13241", null ],
      [ "SHORT", "structas2transition_1_1Config_1_1PredFormat.html#a54e0bd339c456f08ffa6cc9fb856847dadc22a3f9b804b0c9174cc4e9770ac850", null ]
    ] ]
];