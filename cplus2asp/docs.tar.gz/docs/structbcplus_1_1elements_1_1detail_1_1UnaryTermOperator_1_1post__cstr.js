var structbcplus_1_1elements_1_1detail_1_1UnaryTermOperator_1_1post__cstr =
[
    [ "operator()", "structbcplus_1_1elements_1_1detail_1_1UnaryTermOperator_1_1post__cstr.html#a24cd751b468c6a06c093f3da063b01fd", null ]
];