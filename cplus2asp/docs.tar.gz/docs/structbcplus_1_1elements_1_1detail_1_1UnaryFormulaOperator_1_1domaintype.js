var structbcplus_1_1elements_1_1detail_1_1UnaryFormulaOperator_1_1domaintype =
[
    [ "operator()", "structbcplus_1_1elements_1_1detail_1_1UnaryFormulaOperator_1_1domaintype.html#a2c910cd186084ddf3e1ebd83ce5528da", null ]
];