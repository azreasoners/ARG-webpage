var structas2transition_1_1Config_1_1PredType =
[
    [ "type", "structas2transition_1_1Config_1_1PredType.html#a8c54180f739314713bf2bcbe6e5bcb97", [
      [ "POSITIVE", "structas2transition_1_1Config_1_1PredType.html#a8c54180f739314713bf2bcbe6e5bcb97a426287beafa3f8cf68185970e24565f4", null ],
      [ "NEGATIVE", "structas2transition_1_1Config_1_1PredType.html#a8c54180f739314713bf2bcbe6e5bcb97a5b1470ff5f947ef7515c1f1976a46406", null ],
      [ "STRONG_NEGATION", "structas2transition_1_1Config_1_1PredType.html#a8c54180f739314713bf2bcbe6e5bcb97aeebdbf410ea6ad58923a7aff4231836c", null ],
      [ "CONTRIBUTION", "structas2transition_1_1Config_1_1PredType.html#a8c54180f739314713bf2bcbe6e5bcb97af12604c547e3beee95864e2b051f8142", null ],
      [ "XPREDICATE", "structas2transition_1_1Config_1_1PredType.html#a8c54180f739314713bf2bcbe6e5bcb97a5fd97ae013a81b2b4ce8f14cc5662a3c", null ],
      [ "UNKNOWN", "structas2transition_1_1Config_1_1PredType.html#a8c54180f739314713bf2bcbe6e5bcb97aa3c34b4c60f96a96615a4b8ef71d20a5", null ]
    ] ]
];