var structbcplus_1_1elements_1_1detail_1_1NullaryFormulaOperator_1_1cstr =
[
    [ "operator()", "structbcplus_1_1elements_1_1detail_1_1NullaryFormulaOperator_1_1cstr.html#a60fd976a0acc315e49cd29acaa3fc992", null ]
];