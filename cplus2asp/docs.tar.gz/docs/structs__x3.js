var structs__x3 =
[
    [ "count", "structs__x3.html#afe7cafeeae290d801ec8fbe16283e443", null ],
    [ "ht", "structs__x3.html#a47b22a1400ff24645baf04053a061ca9", null ],
    [ "size", "structs__x3.html#af02ce4fa00cf802a36e08ef94bd9e3e7", null ],
    [ "tbl", "structs__x3.html#a4aead3564e2151fdf4f74641516c9868", null ]
];