var structbcplus_1_1elements_1_1detail_1_1UnaryTermOperator_1_1pre__cstr =
[
    [ "operator()", "structbcplus_1_1elements_1_1detail_1_1UnaryTermOperator_1_1pre__cstr.html#a3f4ddad3d350a4cfb89fec2f60419941", null ]
];