var classBigQuantifiers =
[
    [ "Quantifier", "classBigQuantifiers.html#a7955a043286331b5f946b664aa54f82e", null ],
    [ "QuantifierList", "classBigQuantifiers.html#a3ca97554a73aff7ffbc449630282429c", null ],
    [ "QuantifierType", "classBigQuantifiers.html#aa0e04cca26df4d8b43c80fa22a127f79", [
      [ "QUANT_UNKNOWN", "classBigQuantifiers.html#aa0e04cca26df4d8b43c80fa22a127f79a6a36a0100c955921d3d6fe56dbdcf4a2", null ],
      [ "QUANT_CONJ", "classBigQuantifiers.html#aa0e04cca26df4d8b43c80fa22a127f79a7fade65f81134a865e1b2698033e7e85", null ],
      [ "QUANT_DISJ", "classBigQuantifiers.html#aa0e04cca26df4d8b43c80fa22a127f79a4b459148c9d79cf5f0a7985d8c19a079", null ]
    ] ],
    [ "BigQuantifiers", "classBigQuantifiers.html#a75d3f2bec8a1dece54104f2e41b777b3", null ],
    [ "~BigQuantifiers", "classBigQuantifiers.html#afddc860a087b87860379aae9c020a19e", null ],
    [ "addQuant", "classBigQuantifiers.html#afeccce42bd8575a1ab34159ffa920c3f", null ],
    [ "aggregateUndefined", "classBigQuantifiers.html#a226123c32e399d4bf1f8a34c37ec47aa", null ],
    [ "copy", "classBigQuantifiers.html#a1ea01a7fa9da7ff1c84c070e6022bcae", null ],
    [ "detachPostOp", "classBigQuantifiers.html#a11708d79bab32ded8a0c6afb223a4ab0", null ],
    [ "determineQueryIPart", "classBigQuantifiers.html#a0b64c11511ec5335264659b37040c4c8", null ],
    [ "fullName", "classBigQuantifiers.html#a49f94a4965924b36b9f9ba5eff6321ad", null ],
    [ "hasConstants", "classBigQuantifiers.html#a4a152dc9b0ab328c1885300c6267e8e2", null ],
    [ "hasLuaCalls", "classBigQuantifiers.html#a6871897a9da389cd7f2070f51cb0dd8d", null ],
    [ "isArithExpr", "classBigQuantifiers.html#a4352ce6694ac3cdb58cfcba677d43f8d", null ],
    [ "isDefinite", "classBigQuantifiers.html#ab7f9699b4a1491e8798e6944e272bfc1", null ],
    [ "isSingleAtom", "classBigQuantifiers.html#a515e73a637dc0055a979d72803bea4a1", null ],
    [ "numQuants", "classBigQuantifiers.html#a83b7dd7d324364774619127d36c68ac5", null ],
    [ "postOp", "classBigQuantifiers.html#a21aede46ca537d6efa948033a3c3f74b", null ],
    [ "postOp", "classBigQuantifiers.html#a0e146e5a26cebd285587da6c84eff3d2", null ],
    [ "quantsBegin", "classBigQuantifiers.html#adf46481cdc03b26f51a01d20e8f02255", null ],
    [ "quantsBegin", "classBigQuantifiers.html#adbce17b9211f29bdc3dd723a79a93ee4", null ],
    [ "quantsEnd", "classBigQuantifiers.html#a754645955ad27c87055f45234f0acd37", null ],
    [ "quantsEnd", "classBigQuantifiers.html#a8e12fbec31d93b3cb0ce44e2a40aad86", null ],
    [ "translate", "classBigQuantifiers.html#ae9accaee850a3344def43066bb38374c", null ]
];