var namespacebcplus_1_1statements =
[
    [ "detail", "namespacebcplus_1_1statements_1_1detail.html", "namespacebcplus_1_1statements_1_1detail" ],
    [ "QueryStatement", "classbcplus_1_1statements_1_1QueryStatement.html", "classbcplus_1_1statements_1_1QueryStatement" ],
    [ "Statement", "classbcplus_1_1statements_1_1Statement.html", "classbcplus_1_1statements_1_1Statement" ]
];