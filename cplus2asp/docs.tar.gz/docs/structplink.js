var structplink =
[
    [ "cfp", "structplink.html#a9ca45c3b336a9d2d18dcd9efa9289b21", null ],
    [ "next", "structplink.html#a20e0790632a51e2ee8403a884af641bf", null ]
];