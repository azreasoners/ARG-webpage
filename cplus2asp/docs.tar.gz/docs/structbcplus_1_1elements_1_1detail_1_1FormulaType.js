var structbcplus_1_1elements_1_1detail_1_1FormulaType =
[
    [ "type", "structbcplus_1_1elements_1_1detail_1_1FormulaType.html#ae48cdc93ebc930bd4925f5d7283d1c11", [
      [ "BINARY", "structbcplus_1_1elements_1_1detail_1_1FormulaType.html#ae48cdc93ebc930bd4925f5d7283d1c11ae863c529b79773d831cf407d4d387393", null ],
      [ "COMPARISON", "structbcplus_1_1elements_1_1detail_1_1FormulaType.html#ae48cdc93ebc930bd4925f5d7283d1c11a437421e12833727eac22421244f5dba5", null ],
      [ "UNARY", "structbcplus_1_1elements_1_1detail_1_1FormulaType.html#ae48cdc93ebc930bd4925f5d7283d1c11a4958bf26177bd19a8e4918ea62709cee", null ],
      [ "QUANTIFIER", "structbcplus_1_1elements_1_1detail_1_1FormulaType.html#ae48cdc93ebc930bd4925f5d7283d1c11a89118ce5708925ae1688ef392237375b", null ],
      [ "ATOMIC", "structbcplus_1_1elements_1_1detail_1_1FormulaType.html#ae48cdc93ebc930bd4925f5d7283d1c11a5d5ce9478af409a8f1bbcae26eec1fa3", null ],
      [ "NULLARY", "structbcplus_1_1elements_1_1detail_1_1FormulaType.html#ae48cdc93ebc930bd4925f5d7283d1c11ae099f2bc7ae7a6466068ada775573c88", null ],
      [ "CARDINALITY", "structbcplus_1_1elements_1_1detail_1_1FormulaType.html#ae48cdc93ebc930bd4925f5d7283d1c11aa6b78b1350997150fa1f700e4344280c", null ],
      [ "BINDING", "structbcplus_1_1elements_1_1detail_1_1FormulaType.html#ae48cdc93ebc930bd4925f5d7283d1c11a63a4b6c26824a35219a688614de53b6d", null ]
    ] ]
];