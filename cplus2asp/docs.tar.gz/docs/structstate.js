var structstate =
[
    [ "ap", "structstate.html#afa80d424811de1474da00b3a8cb3e74a", null ],
    [ "bp", "structstate.html#aeec1f34de3b451b17c279ebecf68ccc3", null ],
    [ "cfp", "structstate.html#aa904f5ab5e18633aebc199c48014dc1f", null ],
    [ "iDflt", "structstate.html#aa635d045a97d216a756a9603fd9c9c76", null ],
    [ "iNtOfst", "structstate.html#a76c5eafaf09d92e514623f3f3171fba6", null ],
    [ "iTknOfst", "structstate.html#a8b8000826bd6bdea4863293f586efc1b", null ],
    [ "nNtAct", "structstate.html#a1e83b06b14c77fff6ca0cd1439991a3a", null ],
    [ "nTknAct", "structstate.html#a2f282b0c7be7363f1e6b516fc04ec3df", null ],
    [ "statenum", "structstate.html#a6fe8f8d12c6fb07363b03740231628c8", null ]
];