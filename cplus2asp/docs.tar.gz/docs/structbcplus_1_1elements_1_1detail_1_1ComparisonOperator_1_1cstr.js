var structbcplus_1_1elements_1_1detail_1_1ComparisonOperator_1_1cstr =
[
    [ "operator()", "structbcplus_1_1elements_1_1detail_1_1ComparisonOperator_1_1cstr.html#a969403f14f875abaca31cd3066d1a560", null ]
];