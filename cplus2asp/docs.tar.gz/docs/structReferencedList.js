var structReferencedList =
[
    [ "type", "structReferencedList.html#a19d7f531bf69490c8c37237dd3533cd0", null ],
    [ "type", "structReferencedList.html#a19d7f531bf69490c8c37237dd3533cd0", null ]
];