var structbcplus_1_1parser_1_1detail_1_1ScannerSource_1_1Type =
[
    [ "type", "structbcplus_1_1parser_1_1detail_1_1ScannerSource_1_1Type.html#a6ddd677c5ca5d1aa7624f950921fa331", [
      [ "RAW", "structbcplus_1_1parser_1_1detail_1_1ScannerSource_1_1Type.html#a6ddd677c5ca5d1aa7624f950921fa331a8e66ce6249f2c6a14cfa5d2b72272456", null ],
      [ "TOKENS", "structbcplus_1_1parser_1_1detail_1_1ScannerSource_1_1Type.html#a6ddd677c5ca5d1aa7624f950921fa331a9b26cfab2ae4299dd4680f687bf0f929", null ]
    ] ]
];