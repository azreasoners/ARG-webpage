var structs__x3node =
[
    [ "data", "structs__x3node.html#a833eda044d07f12e196b76532ea09cbb", null ],
    [ "from", "structs__x3node.html#a1a60cabfe02354d135dd7c12083c7210", null ],
    [ "key", "structs__x3node.html#af5ba80baa2aa4c6bfa8c86e51b34772f", null ],
    [ "next", "structs__x3node.html#a323c824ef479aebacedf31dfaeb54582", null ]
];