var structacttab =
[
    [ "aAction", "structacttab.html#afb1ee100dd5718f07c60988ee3fb43c3", null ],
    [ "aLookahead", "structacttab.html#af40c645ba153f5630cc4a641544452a9", null ],
    [ "mnAction", "structacttab.html#a034d4761f4a67e49860504e4355cc37b", null ],
    [ "mnLookahead", "structacttab.html#a0d7b48695b227d3b48e6fe61f2dcf41c", null ],
    [ "mxLookahead", "structacttab.html#a466d035d73cff7999cbb4c3a1b8c763d", null ],
    [ "nAction", "structacttab.html#a8f1f0a4b91e02ffe3b978f0c7d5715f2", null ],
    [ "nActionAlloc", "structacttab.html#a4836bf372ea8e78c0ff0cc23d7331330", null ],
    [ "nLookahead", "structacttab.html#ab4063b892cd8c9c11ae0a91630bc2ca2", null ],
    [ "nLookaheadAlloc", "structacttab.html#aa776f649f69a622f6be07eaf538c700a", null ]
];