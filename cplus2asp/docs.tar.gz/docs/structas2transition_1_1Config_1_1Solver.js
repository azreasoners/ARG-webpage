var structas2transition_1_1Config_1_1Solver =
[
    [ "type", "structas2transition_1_1Config_1_1Solver.html#ae45e9096c849e19748783dc4591fc8d1", [
      [ "UNKNOWN", "structas2transition_1_1Config_1_1Solver.html#ae45e9096c849e19748783dc4591fc8d1a2e2d72480c387e68d2b25475dcd496e5", null ],
      [ "SMODELS", "structas2transition_1_1Config_1_1Solver.html#ae45e9096c849e19748783dc4591fc8d1aa31d088df2ba2ab4316ce50bcc6d269f", null ],
      [ "CMODELS", "structas2transition_1_1Config_1_1Solver.html#ae45e9096c849e19748783dc4591fc8d1a9f042aca4d9b759488643c346d3f32b9", null ],
      [ "OCLINGO", "structas2transition_1_1Config_1_1Solver.html#ae45e9096c849e19748783dc4591fc8d1aa4decd5d32afc21ec5cd2565a34ca837", null ]
    ] ]
];