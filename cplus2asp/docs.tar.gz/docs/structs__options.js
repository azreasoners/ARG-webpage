var structs__options =
[
    [ "arg", "structs__options.html#a524597a3b73d72ba780ed8f94677bf27", null ],
    [ "label", "structs__options.html#ab4b656f9243d3bd710cebbaf03e3545d", null ],
    [ "message", "structs__options.html#a8cf3a0ad77544db85090e09841c856f6", null ],
    [ "type", "structs__options.html#a507483deac8a091d8c3c81c7889b3536", null ]
];