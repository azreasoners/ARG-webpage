var structbcplus_1_1elements_1_1detail_1_1NullaryFormulaOperator =
[
    [ "cstr", "structbcplus_1_1elements_1_1detail_1_1NullaryFormulaOperator_1_1cstr.html", "structbcplus_1_1elements_1_1detail_1_1NullaryFormulaOperator_1_1cstr" ],
    [ "domaintype", "structbcplus_1_1elements_1_1detail_1_1NullaryFormulaOperator_1_1domaintype.html", "structbcplus_1_1elements_1_1detail_1_1NullaryFormulaOperator_1_1domaintype" ],
    [ "type", "structbcplus_1_1elements_1_1detail_1_1NullaryFormulaOperator.html#a6670ca67f167551f5f56e79a7dd2b13c", [
      [ "TRUE", "structbcplus_1_1elements_1_1detail_1_1NullaryFormulaOperator.html#a6670ca67f167551f5f56e79a7dd2b13ca765d0afba263c1d5a2a7099acff25754", null ],
      [ "FALSE", "structbcplus_1_1elements_1_1detail_1_1NullaryFormulaOperator.html#a6670ca67f167551f5f56e79a7dd2b13ca70bd3fa285b22a95089cce1ebdc6a23f", null ]
    ] ]
];