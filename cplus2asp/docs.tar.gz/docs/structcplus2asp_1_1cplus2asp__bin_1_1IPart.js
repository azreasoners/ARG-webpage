var structcplus2asp_1_1cplus2asp__bin_1_1IPart =
[
    [ "type", "structcplus2asp_1_1cplus2asp__bin_1_1IPart.html#a9b2410de76c08d735fcfcd5d76ce8816", [
      [ "BASE", "structcplus2asp_1_1cplus2asp__bin_1_1IPart.html#a9b2410de76c08d735fcfcd5d76ce8816af5839ee1be6929f3b1de6cd4625e8aba", null ],
      [ "CUMULATIVE", "structcplus2asp_1_1cplus2asp__bin_1_1IPart.html#a9b2410de76c08d735fcfcd5d76ce8816ab64838ca9abcfd4c2f1415a617bc0975", null ],
      [ "VOLATILE", "structcplus2asp_1_1cplus2asp__bin_1_1IPart.html#a9b2410de76c08d735fcfcd5d76ce8816ad70947fd0c74c471bc7aa54b5be9ceff", null ],
      [ "EXTERNAL", "structcplus2asp_1_1cplus2asp__bin_1_1IPart.html#a9b2410de76c08d735fcfcd5d76ce8816ab287047b2d9d13bc1ddd84b82d1f03df", null ],
      [ "NONE", "structcplus2asp_1_1cplus2asp__bin_1_1IPart.html#a9b2410de76c08d735fcfcd5d76ce8816a6c37095b9f3125b947fa1f096d2eb69e", null ]
    ] ]
];