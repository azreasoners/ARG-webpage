var as2transition_2include_2babb_2utils_2memory_2ReferencedWrapper_8h =
[
    [ "ReferencedWrapper", "classbabb_1_1utils_1_1ReferencedWrapper.html", "classbabb_1_1utils_1_1ReferencedWrapper" ],
    [ "ReferencedString", "as2transition_2include_2babb_2utils_2memory_2ReferencedWrapper_8h.html#ab7659256856b2d3a0639dc97b7a12e98", null ]
];