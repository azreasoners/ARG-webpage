var structbcplus_1_1Configuration_1_1Status =
[
    [ "type", "structbcplus_1_1Configuration_1_1Status.html#addc04a3aa54e7c297ae9108195edaa13", [
      [ "STAT_OK", "structbcplus_1_1Configuration_1_1Status.html#addc04a3aa54e7c297ae9108195edaa13aac28630f079fd5abafebbd46172dde9c", null ],
      [ "STAT_BAD_ARG", "structbcplus_1_1Configuration_1_1Status.html#addc04a3aa54e7c297ae9108195edaa13aef524294fd63c2468973526f33972da3", null ],
      [ "STAT_HELP", "structbcplus_1_1Configuration_1_1Status.html#addc04a3aa54e7c297ae9108195edaa13a81102615e35e0b282d205988dc37a13a", null ],
      [ "STAT_VERSION", "structbcplus_1_1Configuration_1_1Status.html#addc04a3aa54e7c297ae9108195edaa13a1a10c82e905397c78d8f31e0c87891ae", null ],
      [ "STAT_NEXT_ARG", "structbcplus_1_1Configuration_1_1Status.html#addc04a3aa54e7c297ae9108195edaa13a5fe4ee35330bda484de9bb21cde7a0a3", null ]
    ] ]
];