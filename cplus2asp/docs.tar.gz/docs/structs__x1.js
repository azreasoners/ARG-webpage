var structs__x1 =
[
    [ "count", "structs__x1.html#a6caa9df6ff72618f02a7128680d1a88d", null ],
    [ "ht", "structs__x1.html#a2ae1be7a694b5ff027f0c3391694be6d", null ],
    [ "size", "structs__x1.html#ae410b4957e3cad477a2d307481fa1293", null ],
    [ "tbl", "structs__x1.html#ad36b1c972e52eaf2b965638e34c2ad2f", null ]
];