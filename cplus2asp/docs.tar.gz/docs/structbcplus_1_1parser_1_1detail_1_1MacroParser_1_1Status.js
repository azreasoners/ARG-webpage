var structbcplus_1_1parser_1_1detail_1_1MacroParser_1_1Status =
[
    [ "type", "structbcplus_1_1parser_1_1detail_1_1MacroParser_1_1Status.html#a25441ec4f8e59a24b1d69aa33170a311", [
      [ "OK", "structbcplus_1_1parser_1_1detail_1_1MacroParser_1_1Status.html#a25441ec4f8e59a24b1d69aa33170a311a95948eae6cf3bfbd99f5c362e50924ad", null ],
      [ "ERR_IO", "structbcplus_1_1parser_1_1detail_1_1MacroParser_1_1Status.html#a25441ec4f8e59a24b1d69aa33170a311a82b48232d4360eeb367a080e82957386", null ],
      [ "ERR_SYNTAX", "structbcplus_1_1parser_1_1detail_1_1MacroParser_1_1Status.html#a25441ec4f8e59a24b1d69aa33170a311ad776db581d9a9b67282670f8be3e5280", null ],
      [ "END_INPUT", "structbcplus_1_1parser_1_1detail_1_1MacroParser_1_1Status.html#a25441ec4f8e59a24b1d69aa33170a311a666b8eb5edd623512069d7985d432c1a", null ]
    ] ]
];