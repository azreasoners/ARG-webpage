var structbcplus_1_1elements_1_1Element_1_1Type =
[
    [ "type", "structbcplus_1_1elements_1_1Element_1_1Type.html#ac273b3dfbafb20315bc8e94af9102e51", [
      [ "FORMULA", "structbcplus_1_1elements_1_1Element_1_1Type.html#ac273b3dfbafb20315bc8e94af9102e51a643710bdf9fe5b95d4b36f4c8dea549b", null ],
      [ "TERM", "structbcplus_1_1elements_1_1Element_1_1Type.html#ac273b3dfbafb20315bc8e94af9102e51a90399828afb81eb1065f2f4e3a941a28", null ],
      [ "MACRO", "structbcplus_1_1elements_1_1Element_1_1Type.html#ac273b3dfbafb20315bc8e94af9102e51aa6f40c8930a570d3b35d56e32323eb92", null ]
    ] ]
];