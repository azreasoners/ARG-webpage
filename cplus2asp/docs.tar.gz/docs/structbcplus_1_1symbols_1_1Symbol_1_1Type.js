var structbcplus_1_1symbols_1_1Symbol_1_1Type =
[
    [ "Mask", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a63436176ff516ecbe5953d036caa581b", [
      [ "M_ANY", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a63436176ff516ecbe5953d036caa581ba85c9e3bad5e44586dcead61b87c9575c", null ],
      [ "M_TERM", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a63436176ff516ecbe5953d036caa581ba6ccac7378e2905ded0fef027b7dc3544", null ],
      [ "M_FORMULA", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a63436176ff516ecbe5953d036caa581bae9f982cba3996a5e866dcc31b5b6f6ff", null ]
    ] ],
    [ "type", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a2eaa0503b8ebdfaec496534d13fc3d08", [
      [ "SORT", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a2eaa0503b8ebdfaec496534d13fc3d08ab0d3ec7f161664c6e75be81ba2067e47", null ],
      [ "CONSTANT", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a2eaa0503b8ebdfaec496534d13fc3d08a370dfbf7af339762836c6a4e09ec5a37", null ],
      [ "VARIABLE", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a2eaa0503b8ebdfaec496534d13fc3d08ab5bd4ae46ba7bef0a82f0519e4ef0ea3", null ],
      [ "OBJECT", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a2eaa0503b8ebdfaec496534d13fc3d08a987cc6a0507c78cd07794b26cc39cabd", null ],
      [ "MACRO", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a2eaa0503b8ebdfaec496534d13fc3d08a760f67361bd092176105e20b77a152e5", null ],
      [ "QUERY", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a2eaa0503b8ebdfaec496534d13fc3d08aa7753d473e49cd914a8f6082e9021ad0", null ],
      [ "RANGE", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a2eaa0503b8ebdfaec496534d13fc3d08a3ad425da43b44ddcce63d80528d78f84", null ],
      [ "_LARGEST_", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a2eaa0503b8ebdfaec496534d13fc3d08ab662522da19f00742d97ff2512797c5a", null ],
      [ "ERR_INVALID_SYMBOL", "structbcplus_1_1symbols_1_1Symbol_1_1Type.html#a2eaa0503b8ebdfaec496534d13fc3d08a43edbde043d03be6ef48f3445da9be8a", null ]
    ] ]
];