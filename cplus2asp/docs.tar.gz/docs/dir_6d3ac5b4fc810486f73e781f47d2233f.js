var dir_6d3ac5b4fc810486f73e781f47d2233f =
[
    [ "detail", "dir_d2feda497e157515d1b47d5e37ee77f0.html", "dir_d2feda497e157515d1b47d5e37ee77f0" ],
    [ "AtomicFormula.h", "AtomicFormula_8h.html", [
      [ "AtomicFormula", "classbcplus_1_1elements_1_1AtomicFormula.html", "classbcplus_1_1elements_1_1AtomicFormula" ]
    ] ],
    [ "CardinalityFormula.h", "CardinalityFormula_8h.html", [
      [ "CardinalityFormula", "classbcplus_1_1elements_1_1CardinalityFormula.html", "classbcplus_1_1elements_1_1CardinalityFormula" ]
    ] ],
    [ "Element.h", "Element_8h.html", "Element_8h" ],
    [ "elements.h", "elements_8h.html", null ],
    [ "formulas.h", "formulas_8h.html", "formulas_8h" ],
    [ "Macro.h", "Macro_8h.html", [
      [ "Macro", "classbcplus_1_1elements_1_1Macro.html", "classbcplus_1_1elements_1_1Macro" ]
    ] ],
    [ "QuantifierFormula.h", "QuantifierFormula_8h.html", [
      [ "QuantifierFormula", "classbcplus_1_1elements_1_1QuantifierFormula.html", "classbcplus_1_1elements_1_1QuantifierFormula" ],
      [ "Operator", "structbcplus_1_1elements_1_1QuantifierFormula_1_1Operator.html", "structbcplus_1_1elements_1_1QuantifierFormula_1_1Operator" ]
    ] ],
    [ "terms.h", "terms_8h.html", "terms_8h" ]
];