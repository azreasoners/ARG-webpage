var structs__x4node =
[
    [ "data", "structs__x4node.html#ac430148e8ed003d88121ee0d6d507ffa", null ],
    [ "from", "structs__x4node.html#a0d6da6d5e2f9752696c9ef270c5a2415", null ],
    [ "next", "structs__x4node.html#a9b7d7519647e8fbb059af76096df24b0", null ]
];