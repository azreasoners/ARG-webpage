// $Id: Version.java,v 1.2 2004/09/21 14:30:27 jan Exp $
package jpl;
class Version
{
	public final int    major            = 3;
	public final int    minor            = 0;
	public final int    patch            = 3;
	public final String status           = "alpha";
}
