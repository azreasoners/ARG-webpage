#!/bin/sh

. ../env.sh

run_preloaded SemWeb

