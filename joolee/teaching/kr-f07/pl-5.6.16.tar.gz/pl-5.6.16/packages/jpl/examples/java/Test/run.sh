#!/bin/sh

. ../env.sh

run Test

