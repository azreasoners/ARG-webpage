/* Define if you have the nsl library (-lnsl).  */
#undef HAVE_LIBNSL

/* Define if you have the socket library (-lsocket).  */
#undef HAVE_LIBSOCKET

/* Define to prepare for multi-threading */
#undef _REENTRANT

/* Define if DB_ENV defines ->set_rpc_server rather then ->set_server */
#undef HAVE_SET_RPC_SERVER
